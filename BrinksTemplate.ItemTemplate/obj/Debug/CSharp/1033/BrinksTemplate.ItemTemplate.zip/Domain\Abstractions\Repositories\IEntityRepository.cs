﻿using $DomainRepositoriesInterfaceNamespace$;
using $DomainEntitiesNamespace$;
using $DataAccessInfrastructureEFNamespace$;
using $DataAccessInfrastructureEFInterfacesNamespace$;

namespace $DomainRepositoriesInterfaceNamespace$
{
    public interface I$EntityName$Repository : IRepository<$EntityName$>
    {
    }
}
