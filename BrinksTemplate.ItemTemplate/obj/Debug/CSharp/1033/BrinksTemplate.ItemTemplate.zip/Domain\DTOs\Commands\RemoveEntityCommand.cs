﻿namespace $DomainCommandsNamespace$
{
    public class Remove$EntityName$Command
    {
    }
}
