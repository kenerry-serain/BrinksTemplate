﻿namespace $DomainQueriesNamespace$
{
    public class $EntityName$Query
    {
        public int Id { get; set; }
    }
}
