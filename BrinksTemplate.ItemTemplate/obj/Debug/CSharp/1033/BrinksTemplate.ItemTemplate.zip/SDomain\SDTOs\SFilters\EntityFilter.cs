﻿
namespace $DomainFiltersNamespace$
{
    public class $EntityName$Filter
    {
    }
}
