﻿using $DomainEntitiesNamespace$;
using $DataAccessInfrastructureEFInterfacesNamespace$;

namespace $DomainReadOnlyRepositoriesInterfaceNamespace$
{
    public interface I$EntityName$ReadOnlyRepository : IReadOnlyRepository<$EntityName$>
    {
    }
}
