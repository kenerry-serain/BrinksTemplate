﻿namespace $DomainCommandsNamespace$
{
    public class Update$EntityNameCommand$Command
    {
        public int Id { get; set; }
    }
}
