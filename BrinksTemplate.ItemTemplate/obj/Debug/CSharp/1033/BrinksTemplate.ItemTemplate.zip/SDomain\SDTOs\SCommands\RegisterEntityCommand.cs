﻿namespace $DomainCommandsNamespace$.$EntityName$
{
    /// <summary>
    /// Comando de registro da entidade $EntityName$
    /// </summary>
    public class Register$EntityName$Command
    {
        public int Id { get; set; }
    }
}
