﻿namespace $DomainCommandsNamespace$.$EntityName$
{
    /// <summary>
    /// Comando de atualização da entidade $EntityName$
    /// </summary>
    public class Update$EntityName$Command
    {
        public int Id { get; set; }
    }
}
