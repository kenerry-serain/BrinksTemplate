﻿using $CoreSharedKernelNamespace$;

namespace $DomainEntitiesNamespace$
{
    public class $EntityName$ : Entity
    {
    }
}
