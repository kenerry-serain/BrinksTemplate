﻿namespace $DomainCommandsNamespace$
{
    public class Register$EntityName$Command
    {
        public int Id { get; set; }
    }
}
