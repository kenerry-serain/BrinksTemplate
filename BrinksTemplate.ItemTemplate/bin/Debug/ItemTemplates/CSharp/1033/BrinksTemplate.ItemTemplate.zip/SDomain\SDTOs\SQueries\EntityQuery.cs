﻿namespace $DomainQueriesNamespace$.$EntityName$
{
    /// <summary>
    /// View Model da entidade $EntityName$
    /// </summary>
    public class $EntityName$Query
    {
        public int Id { get; set; }
    }
}
