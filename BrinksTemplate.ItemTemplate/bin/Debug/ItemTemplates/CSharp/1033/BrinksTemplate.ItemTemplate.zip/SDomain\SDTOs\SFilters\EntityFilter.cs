﻿
namespace $DomainFiltersNamespace$.$EntityName$
{
    /// <summary>
    /// Filtro da entidade $EntityName$
    /// </summary>
    public class $EntityName$Filter
    {
    }
}
